//
//  ViewController.swift
//  OGrandeTeste
//
//  Created by Aluno01 on 11/05/22.
//  Copyright © 2022 Eldorado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var começo: UILabel!
    @IBOutlet weak var primeiroBot: UIButton!
    
    
            
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

